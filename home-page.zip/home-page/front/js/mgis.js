$(document).ready((function() {
    var g = "https://www.bibs.co.in/front/";
    $("#con-ceo-one").magnificPopup({
        items: [{
            src: g + "img/mgis/img-1.png"
        }, {
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-6.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#con-ceo-two").magnificPopup({
        items: [{
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-6.png"
        }, {
            src: g + "img/mgis/img-1.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#con-ceo-three").magnificPopup({
        items: [{
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-6.png"
        }, {
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-1.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#con-ceo-four").magnificPopup({
        items: [{
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-6.png"
        }, {
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-1.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#con-ceo-fifth").magnificPopup({
        items: [{
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-6.png"
        }, {
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-1.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#con-ceo-sixth").magnificPopup({
        items: [{
            src: g + "img/mgis/img-6.png"
        }, {
            src: g + "img/mgis/img-5.png"
        }, {
            src: g + "img/mgis/img-4.png"
        }, {
            src: g + "img/mgis/img-3.png"
        }, {
            src: g + "img/mgis/img-2.png"
        }, {
            src: g + "img/mgis/img-1.png"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    })
}));