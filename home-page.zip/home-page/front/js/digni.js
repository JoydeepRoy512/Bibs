$(document).ready((function() {
    var g = "https://www.bibs.co.in/front/";
    $("#one-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-9.jpg"
        }, {
            src: g + "img/mgis/img-10.jpg"
        }, {
            src: g + "img/mgis/img-11.jpg"
        }, {
            src: g + "img/mgis/img-12.jpg"
        }, {
            src: g + "img/mgis/img-13.jpg"
        }, {
            src: g + "img/mgis/img-14.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#two-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-10.jpg"
        }, {
            src: g + "img/mgis/img-11.jpg"
        }, {
            src: g + "img/mgis/img-12.jpg"
        }, {
            src: g + "img/mgis/img-13.jpg"
        }, {
            src: g + "img/mgis/img-14.jpg"
        }, {
            src: g + "img/mgis/img-9.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#three-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-11.jpg"
        }, {
            src: g + "img/mgis/img-12.jpg"
        }, {
            src: g + "img/mgis/img-13.jpg"
        }, {
            src: g + "img/mgis/img-14.jpg"
        }, {
            src: g + "img/mgis/img-9.jpg"
        }, {
            src: g + "img/mgis/img-10.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#four-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-12.jpg"
        }, {
            src: g + "img/mgis/img-13.jpg"
        }, {
            src: g + "img/mgis/img-14.jpg"
        }, {
            src: g + "img/mgis/img-9.jpg"
        }, {
            src: g + "img/mgis/img-10.jpg"
        }, {
            src: g + "img/mgis/img-11.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#fifth-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-13.jpg"
        }, {
            src: g + "img/mgis/img-14.jpg"
        }, {
            src: g + "img/mgis/img-9.jpg"
        }, {
            src: g + "img/mgis/img-10.jpg"
        }, {
            src: g + "img/mgis/img-11.jpg"
        }, {
            src: g + "img/mgis/img-12.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    }), $("#sixth-dig").magnificPopup({
        items: [{
            src: g + "img/mgis/img-14.jpg"
        }, {
            src: g + "img/mgis/img-9.jpg"
        }, {
            src: g + "img/mgis/img-10.jpg"
        }, {
            src: g + "img/mgis/img-11.jpg"
        }, {
            src: g + "img/mgis/img-12.jpg"
        }, {
            src: g + "img/mgis/img-13.jpg"
        }],
        gallery: {
            enabled: !0
        },
        type: "image"
    })
}));