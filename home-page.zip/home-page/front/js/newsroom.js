$(document).ready(function() {
    var url = "https://www.bibs.co.in/front/";
    $('#pop-one').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-1.png',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-two').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-2.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-three').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-3.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-four').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-4.png',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-fifth').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-5.png',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-sixth').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-6.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-seventh').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-7.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-eight').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-8.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-nine').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-9.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-ten').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-10.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-eleven').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-11.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twelv').magnificPopup({
        items: [{
            src: url + 'img/newsroom/img-12.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-therteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-1.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-fouteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-2.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-fifteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-3.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-sixteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-4.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-seventeen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-5.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });

    $('#pop-eighteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-6.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-ninteen').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-7.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twenty').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-8.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twenty-one').magnificPopup({
        items: [{
            src: url + 'img/news-paper/img-11.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twenty-two').magnificPopup({
        items: [{
            src: url + 'img/news-paper/samaggya-newspaper.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twenty-third').magnificPopup({
        items: [{
            src: url + 'img/evants/bibs-1.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });
    $('#pop-twenty-fourth').magnificPopup({
        items: [{
            src: url + 'img/evants/article.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });

    $('#pop-twenty-five').magnificPopup({
        items: [{
            src: url + 'img/evants/bibs-eng-1.jpg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });

    $('#pop-twenty-six').magnificPopup({
        items: [{
            src: url + 'img/evants/bibs-ben-1.jpeg',
        }, ],
        gallery: {
            enabled: true
        },
        type: 'image' // this is default type
    });

});